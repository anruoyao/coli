<?php
return [
	'categories' => [
		'entertainment' => 'Entertainment',
		'news' => 'News',
		'sport' => 'Sport',
		'technologies' => 'Technologies',
		'science' => 'Science',
		'education' => 'Education',
		'health' => 'Health',
		'fashion' => 'Fashion',
		'food' => 'Food',
		'travel' => 'Travel',
		'business' => 'Business',
		'music' => 'Music',
		'art' => 'Art',
		'gaming' => 'Gaming',
		'literature' => 'Literature',
		'finance' => 'Finance',
		'politics' => 'Politics',
		'automobiles' => 'Automobiles',
		'fitness' => 'Fitness',
		'home-and-garden' => 'Home and garden',
	]
];
